# openmusic-api v1
submission dicoding back-end
passed all postman api test.
